# import the sql file in your database
# Change the credential in city.php
# Run index.php file